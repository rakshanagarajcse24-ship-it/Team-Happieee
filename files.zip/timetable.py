#!/usr/bin/env python3
"""
Exam Timetable Scheduling = capacitated graph colouring.

Courses are vertices, conflicts are edges, a slot is a colour class that holds
at most R courses. Goal: fewest slots.

Algorithms
  * Welsh-Powell   greedy, descending degree
  * DSatur         greedy, most-saturated course first
  * Exact B&B      DSatur-ordered branch and bound (proves optimality unless
                   the time limit is hit)

Usage
  python timetable.py --file input.txt                 # Option 1: "N M R" + M edges
  python timetable.py --random 25 4 --density 0.3      # Option 2: N R + density
  add  --plot   to draw graph + timetable
       --animate to animate the assignment order
       --bench  to compare algorithms as N grows
       --out timetable.csv  to choose the CSV name
Only the standard library is needed for the solver; matplotlib is needed
for --plot / --animate / --bench.
"""
import argparse
import csv
import math
import random
import sys
import time
from dataclasses import dataclass, field

sys.setrecursionlimit(10000)


# ----------------------------------------------------------------- graph ----
class Graph:
    def __init__(self, n, edges):
        self.n = n
        self.adj = [set() for _ in range(n)]
        for u, v in edges:
            if u != v:                       # ignore self-loops; sets drop duplicates
                self.adj[u].add(v)
                self.adj[v].add(u)
        self.deg = [len(a) for a in self.adj]
        self.m = sum(self.deg) // 2


def parse_input(text):
    """Option 1: first line 'N M R', then M lines 'u v' (1-indexed)."""
    try:
        tk = [int(x) for x in text.split()]
    except ValueError:
        raise ValueError("Input must contain only integers.")
    if len(tk) < 3:
        raise ValueError("Expected: N M R followed by M edge pairs.")
    n, m, r = tk[:3]
    if n < 1 or r < 1 or m < 0:
        raise ValueError("Need N >= 1, R >= 1, M >= 0.")
    if len(tk) < 3 + 2 * m:
        raise ValueError("Fewer edge lines than M.")
    edges = []
    for i in range(m):
        u, v = tk[3 + 2 * i], tk[4 + 2 * i]
        if not (1 <= u <= n and 1 <= v <= n):
            raise ValueError(f"Edge {i + 1}: course numbers must be in 1..{n}.")
        edges.append((u - 1, v - 1))
    return Graph(n, edges), r


def random_graph(n, density, seed=None):
    """Option 2: each possible conflict appears with probability `density`."""
    if n < 1:
        raise ValueError("N must be >= 1.")
    if not 0 <= density <= 1:
        raise ValueError("Density must be between 0 and 1.")
    rnd = random.Random(seed)
    return Graph(n, [(i, j) for i in range(n) for j in range(i + 1, n)
                     if rnd.random() < density])


# ---------------------------------------------------------------- result ----
@dataclass
class Result:
    name: str
    color: list                  # color[v] = slot index (0-based)
    order: list                  # order in which courses were assigned
    ms: float
    nodes: int = 0
    proven: bool = False         # exact search finished
    lb: int = 0
    slots: int = field(init=False)
    optimal: bool = False
    valid: bool = False

    def __post_init__(self):
        self.slots = max(self.color) + 1

    def slot_lists(self, n):
        out = [[] for _ in range(self.slots)]
        for v in range(n):
            out[self.color[v]].append(v)
        return out


def is_valid(g, r, color):
    """Re-check a timetable: every course placed, no conflicts, no slot over R."""
    cnt = {}
    for u in range(g.n):
        if color[u] < 0:
            return False
        cnt[color[u]] = cnt.get(color[u], 0) + 1
        if cnt[color[u]] > r:
            return False
        if any(color[v] == color[u] for v in g.adj[u]):
            return False
    return True


# ------------------------------------------------------------ algorithms ----
def lower_bound(g, r):
    """max(greedy clique size, ceil(N / R)). A clique needs distinct slots;
    N courses need at least ceil(N / R) slots of capacity R."""
    best = 1
    by_deg = sorted(range(g.n), key=lambda v: -g.deg[v])
    for s in by_deg:
        clique = [s]
        for v in by_deg:
            if v != s and all(v in g.adj[u] for u in clique):
                clique.append(v)
        best = max(best, len(clique))
    return max(best, math.ceil(g.n / r))


def first_fit(g, r, v, color, cnt):
    """Lowest slot with no conflicting course and a free hall (else a new slot)."""
    bad = {color[w] for w in g.adj[v] if color[w] >= 0}
    s = 0
    while s in bad or cnt[s] >= r:
        s += 1
    color[v] = s
    cnt[s] += 1


def saturation(g, color, v):
    return len({color[w] for w in g.adj[v] if color[w] >= 0})


def pick_dsatur(g, color):
    """Uncoloured vertex with max saturation; ties broken by degree."""
    best, key = -1, (-1, -1)
    for v in range(g.n):
        if color[v] < 0:
            k = (saturation(g, color, v), g.deg[v])
            if k > key:
                best, key = v, k
    return best


def welsh_powell(g, r):
    t0 = time.perf_counter()
    color, cnt = [-1] * g.n, [0] * (g.n + 1)
    order = sorted(range(g.n), key=lambda v: (-g.deg[v], v))
    for v in order:
        first_fit(g, r, v, color, cnt)
    return Result("Welsh-Powell", color, order, (time.perf_counter() - t0) * 1000)


def dsatur(g, r):
    t0 = time.perf_counter()
    color, cnt, order = [-1] * g.n, [0] * (g.n + 1), []
    for _ in range(g.n):
        v = pick_dsatur(g, color)
        first_fit(g, r, v, color, cnt)
        order.append(v)
    return Result("DSatur", color, order, (time.perf_counter() - t0) * 1000)


def exact(g, r, ub, lb, limit):
    """Branch and bound.
    * Vertex order: DSatur (most constrained first).
    * Symmetry breaking: at most one new slot is opened per branch.
    * Bound 1: k + ceil((unassigned - free seats) / R) >= best  -> prune.
    * Bound 2: opening a slot that cannot beat best  -> prune.
    * Stop early once best == lower bound.
    If the search ends without timing out, `best` is optimal by exhaustion."""
    t0 = time.perf_counter()
    n = g.n
    best = {"color": list(ub.color), "k": ub.slots, "order": list(ub.order)}
    color, cnt, order = [-1] * n, [0] * (n + 1), []
    st = {"nodes": 0, "timeout": False}

    def dfs(k, done):
        if st["timeout"] or best["k"] <= lb:
            return
        st["nodes"] += 1
        if st["nodes"] & 1023 == 0 and time.perf_counter() - t0 > limit:
            st["timeout"] = True
            return
        if done == n:
            best.update(color=list(color), k=k, order=list(order))
            return
        free = sum(r - cnt[s] for s in range(k))
        need = n - done - free
        if k + (math.ceil(need / r) if need > 0 else 0) >= best["k"]:
            return
        v = pick_dsatur(g, color)
        bad = {color[w] for w in g.adj[v] if color[w] >= 0}
        for s in range(k + 1):               # s == k means "open a new slot"
            if s == k and k + 1 >= best["k"]:
                break
            if s in bad or cnt[s] >= r:
                continue
            color[v] = s
            cnt[s] += 1
            order.append(v)
            dfs(k + 1 if s == k else k, done + 1)
            order.pop()
            cnt[s] -= 1
            color[v] = -1
            if st["timeout"] or best["k"] <= lb:
                return

    dfs(0, 0)
    return Result("Exact B&B", best["color"], best["order"],
                  (time.perf_counter() - t0) * 1000,
                  nodes=st["nodes"], proven=not st["timeout"])


def run_all(g, r, limit=3.0):
    lb = lower_bound(g, r)
    wp, ds = welsh_powell(g, r), dsatur(g, r)
    ex = exact(g, r, ds if ds.slots <= wp.slots else wp, lb, limit)
    results = [wp, ds, ex]
    for x in results:
        x.lb = lb
        x.optimal = x.slots <= lb or x.proven
        x.valid = is_valid(g, r, x.color)
    return results


# --------------------------------------------------------------- outputs ----
def print_report(g, r, results):
    dens = 200 * g.m / (g.n * (g.n - 1)) if g.n > 1 else 0
    print(f"N = {g.n}  conflicts M = {g.m} (density {dens:.1f}%)  R = {r}\n")
    print(f"{'Algorithm':<14}{'Slots':>6}{'LB':>5}  {'Proven optimal?':<18}"
          f"{'Time ms':>10}{'Nodes':>10}  Valid")
    for x in results:
        opt = "Yes" if x.optimal else "No (best found)"
        nodes = x.nodes if x.name == "Exact B&B" else "-"
        print(f"{x.name:<14}{x.slots:>6}{x.lb:>5}  {opt:<18}"
              f"{x.ms:>10.2f}{str(nodes):>10}  {'OK' if x.valid else 'FAIL'}")


def print_timetable(g, res):
    print(f"\nTimetable ({res.name}, {res.slots} slots)")
    for s, courses in enumerate(res.slot_lists(g.n), 1):
        print(f"Slot {s}: {', '.join(str(v + 1) for v in courses)}")


def write_csv(g, res, path):
    """Rows = slots, columns = halls (only as many as the fullest slot uses)."""
    sl = res.slot_lists(g.n)
    width = max(len(a) for a in sl)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Slot"] + [f"Hall {i + 1}" for i in range(width)])
        for s, a in enumerate(sl, 1):
            w.writerow([s] + [v + 1 for v in a] + [""] * (width - len(a)))


# --------------------------------------------------------- visualisation ----
def palette(k):
    import colorsys
    return [colorsys.hls_to_rgb((i * 0.61803) % 1, 0.62, 0.7) for i in range(k)]


def layout(n):
    return [(math.cos(2 * math.pi * i / n - math.pi / 2),
             math.sin(2 * math.pi * i / n - math.pi / 2)) for i in range(n)]


def draw_graph(ax, g, res, shown, highlight=None):
    pos, cols = layout(g.n), palette(res.slots)
    ax.clear()
    for u in range(g.n):
        for v in g.adj[u]:
            if u < v:
                ax.plot([pos[u][0], pos[v][0]], [pos[u][1], pos[v][1]],
                        color="#9aa5b8", lw=.6, alpha=.5, zorder=1)
    size = max(60, min(500, 9000 / g.n))
    for v in range(g.n):
        on = v in shown
        ax.scatter(*pos[v], s=size, color=cols[res.color[v]] if on else "#d8dde6",
                   edgecolors="black" if v == highlight else "#333",
                   linewidths=2.5 if v == highlight else .6, zorder=2)
        if g.n <= 60:
            ax.text(pos[v][0], pos[v][1], str(v + 1), ha="center", va="center",
                    fontsize=7, zorder=3)
    ax.set_aspect("equal")
    ax.axis("off")


def draw_grid(ax, g, res, shown=None):
    sl = res.slot_lists(g.n)
    cols = palette(res.slots)
    width = max(1, max(len(a) for a in sl))
    ax.clear()
    ax.axis("off")
    text, colours = [], []
    for s, a in enumerate(sl):
        a = [v for v in a if shown is None or v in shown]
        text.append([f"C{v + 1}" for v in a] + [""] * (width - len(a)))
        colours.append([cols[s] if i < len(a) else "white" for i in range(width)])
    t = ax.table(cellText=text, cellColours=colours,
                 rowLabels=[f"Slot {i + 1}" for i in range(res.slots)],
                 colLabels=[f"Hall {i + 1}" for i in range(width)], loc="center")
    t.auto_set_font_size(False)
    t.set_fontsize(8)
    t.scale(1, 1.25)


def plot_result(g, res):
    import matplotlib.pyplot as plt
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 6))
    draw_graph(a1, g, res, set(range(g.n)))
    a1.set_title(f"Conflict graph - {res.name}: {res.slots} slots")
    draw_grid(a2, g, res)
    a2.set_title("Timetable")
    fig.tight_layout()
    plt.show()


def animate_result(g, res):
    import matplotlib.pyplot as plt
    from matplotlib.animation import FuncAnimation
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 6))

    def frame(k):
        shown = set(res.order[:k])
        hl = res.order[k - 1] if k else None
        draw_graph(a1, g, res, shown, hl)
        draw_grid(a2, g, res, shown)
        a1.set_title(f"{res.name}: step {k}/{g.n}" +
                     (f" - course {hl + 1} -> slot {res.color[hl] + 1}" if hl is not None else ""))
    anim = FuncAnimation(fig, frame, frames=g.n + 1, interval=450, repeat=False)
    fig.tight_layout()
    plt.show()
    return anim


def bench_data(r, density, max_n, limit):
    """Run all algorithms for N = 6..max_n on random graphs (same R, density)."""
    step = max(2, round(max_n / 10))
    ns = list(range(6, max_n + 1, step))
    names = ["Welsh-Powell", "DSatur", "Exact B&B"]
    slots = {k: [] for k in names}
    times = {k: [] for k in names}
    for n in ns:
        print(f"benchmark N = {n} ...", flush=True)
        for x in run_all(random_graph(n, density, seed=n * 7 + 1), r, limit):
            slots[x.name].append(x.slots)
            times[x.name].append(round(max(x.ms, 0.01), 3))
    return {"ns": ns, "slots": slots, "times": times, "r": r,
            "density": density, "limit": limit}


def benchmark(r, density, max_n, limit):
    import matplotlib.pyplot as plt
    d = bench_data(r, density, max_n, limit)
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.5))
    for k in d["slots"]:
        a1.plot(d["ns"], d["slots"][k], marker="o", label=k)
        a2.plot(d["ns"], d["times"][k], marker="o", label=k)
    a1.set(title="Slots used", xlabel="N courses", ylabel="slots")
    a2.set(title="Running time", xlabel="N courses", ylabel="ms (log)", yscale="log")
    a1.legend()
    a2.legend()
    fig.suptitle(f"R = {r}, density = {density:.0%}, exact limit {limit}s")
    fig.tight_layout()
    plt.show()


# ------------------------------------------------- standalone HTML report ----
HTML = r"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Exam Timetable Report</title>
<style>
body{margin:0;background:#0b1220;color:#eaf1ff;font:14px/1.5 "Segoe UI",Arial,sans-serif;padding:18px 3%}
h1{font-size:20px;margin:0 0 4px}h2{font-size:12px;letter-spacing:1px;text-transform:uppercase;color:#55e6ff;margin:0 0 10px}
.m{color:#93a4c0;font-size:12px}.c{background:#131d31;border:1px solid #2a3a57;border-radius:12px;padding:14px;margin:14px 0;max-width:1200px}
table{border-collapse:collapse;font-size:12px}th,td{border:1px solid #2a3a57;padding:5px 9px;text-align:center;white-space:nowrap}th{background:#0e1727;color:#93a4c0}
#grid td{color:#0b1220;font-weight:700;min-width:52px}.ok{color:#5df2b0}.no{color:#ff6f87}.s{overflow-x:auto}
canvas{width:100%;height:auto;background:#09111e;border:1px solid #2a3a57;border-radius:9px;display:block}
button,select,input{background:#1a2840;color:#eaf1ff;border:1px solid #34445e;border-radius:7px;padding:7px 10px;font:inherit}
pre{background:#09111e;border:1px solid #2a3a57;border-radius:8px;padding:10px;font-size:12px;max-height:200px;overflow:auto}
.g{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:800px){.g{grid-template-columns:1fr}}
</style></head><body>
<h1>Exam Timetable Scheduling Report</h1><div class="m" id="info"></div>
<div class="c"><h2>Output 1 - minimum slots per algorithm</h2><div class="s"><table id="res"></table></div></div>
<div class="c"><h2>Conflict graph</h2>
<select id="view"></select> <button id="play">Animate assignment order</button> <button id="all">Show final</button>
<span class="m" id="step"></span><br><br><canvas id="gc" width="640" height="520"></canvas></div>
<div class="c"><h2>Output 2 and 3 - timetable</h2><div class="s"><table id="grid"></table></div>
<pre id="slots"></pre><button id="csv">Download CSV</button></div>
<div class="c"><h2>Comparison as N increases</h2><div class="m" id="bm"></div>
<div class="g"><canvas id="c1" width="480" height="300"></canvas><canvas id="c2" width="480" height="300"></canvas></div></div>
<script>
const D=__DATA__,$=i=>document.getElementById(i),clr=s=>`hsl(${(s*137.508)%360} 72% 58%)`;
const n=D.n,adj=Array.from({length:n},()=>[]);D.edges.forEach(([u,v])=>{adj[u].push(v);adj[v].push(u)});
let tm=null;
$("info").textContent=`N = ${n} | conflicts M = ${D.edges.length} | halls per slot R = ${D.r}`;
$("res").innerHTML="<tr><th>Algorithm</th><th>Min slots</th><th>Lower bound</th><th>Proven optimal?</th><th>Time (ms)</th><th>B&B nodes</th><th>Valid</th></tr>"+
D.results.map(x=>`<tr><th>${x.name}</th><td>${x.slots}</td><td>${x.lb}</td><td class="${x.optimal?"ok":"no"}">${x.optimal?"Yes":"No (best found)"}</td><td>${x.ms.toFixed(2)}</td><td>${x.name=="Exact B&B"?x.nodes:"-"}</td><td class="${x.valid?"ok":"no"}">${x.valid?"OK":"FAIL"}</td></tr>`).join("");
$("view").innerHTML=D.results.map(x=>`<option>${x.name}</option>`).join("");$("view").value="Exact B&B";
const cur=()=>D.results.find(x=>x.name==$("view").value);
const slotsOf=(r,set)=>{const a=Array.from({length:r.slots},()=>[]);for(let v=0;v<n;v++)if(!set||set.has(v))a[r.color[v]].push(v);return a};
function render(k){const r=cur(),kk=k===undefined?n:k,sh=new Set(r.order.slice(0,kk)),hl=kk>0&&kk<n?r.order[kk-1]:-1;
const c=$("gc"),x=c.getContext("2d"),W=c.width,H=c.height,rad=Math.min(W,H)/2-26;x.clearRect(0,0,W,H);
const P=i=>[W/2+rad*Math.cos(2*Math.PI*i/n-Math.PI/2),H/2+rad*Math.sin(2*Math.PI*i/n-Math.PI/2)];
x.strokeStyle="rgba(147,164,192,.28)";x.beginPath();for(let u=0;u<n;u++)for(const v of adj[u])if(u<v){const[a,b]=P(u),[e,f]=P(v);x.moveTo(a,b);x.lineTo(e,f)}x.stroke();
const nr=Math.max(6,Math.min(18,rad*Math.PI/n*.8));
for(let i=0;i<n;i++){const[a,b]=P(i),on=sh.has(i);x.beginPath();x.arc(a,b,nr,0,7);x.fillStyle=on?clr(r.color[i]):"#26334b";x.fill();x.lineWidth=i==hl?3:1;x.strokeStyle=i==hl?"#fff":"#0b1220";x.stroke();
if(nr>=9){x.fillStyle=on?"#0b1220":"#93a4c0";x.font="bold "+Math.round(nr*.9)+"px Arial";x.textAlign="center";x.textBaseline="middle";x.fillText(i+1,a,b)}}
const sl=slotsOf(r,sh),mx=Math.max(1,...sl.map(a=>a.length));
$("grid").innerHTML="<tr><th>Slot</th>"+Array.from({length:mx},(_,i)=>`<th>Hall ${i+1}</th>`).join("")+"</tr>"+
sl.map((a,s)=>`<tr><th>${s+1}</th>`+Array.from({length:mx},(_,i)=>a[i]!==undefined?`<td style="background:${clr(s)}">C${a[i]+1}</td>`:"<td></td>").join("")+"</tr>").join("");
$("slots").textContent=slotsOf(r).map((a,s)=>`Slot ${s+1}: ${a.map(v=>v+1).join(", ")}`).join("\n")}
function stop(){clearInterval(tm);tm=null}
$("play").onclick=()=>{stop();const r=cur();let k=0;render(0);tm=setInterval(()=>{k++;render(k);const v=r.order[k-1];$("step").textContent=` Step ${k}/${n}: course ${v+1} -> slot ${r.color[v]+1}`;if(k>=n)stop()},350)};
$("all").onclick=()=>{stop();$("step").textContent="";render()};$("view").onchange=()=>{stop();render()};
$("csv").onclick=()=>{const r=cur(),sl=slotsOf(r),mx=Math.max(...sl.map(a=>a.length));let s="Slot,"+Array.from({length:mx},(_,i)=>"Hall "+(i+1)).join(",")+"\n";
sl.forEach((a,i)=>{s+=(i+1)+","+Array.from({length:mx},(_,j)=>a[j]!==undefined?a[j]+1:"").join(",")+"\n"});
const u=URL.createObjectURL(new Blob([s],{type:"text/csv"})),l=document.createElement("a");l.href=u;l.download="timetable.csv";l.click()};
function chart(id,xs,ser,log,title){const c=$(id),x=c.getContext("2d"),W=c.width,H=c.height,L=46,B=28,T=26,R=12;x.clearRect(0,0,W,H);
const f=log?v=>Math.log10(Math.max(v,.01)):v=>v,lo=log?-2:0;let hi=Math.max(...ser.flatMap(s=>s.ys.map(f)),lo+1);if(!log)hi=Math.ceil(hi);
const X=i=>L+(W-L-R)*(xs.length>1?i/(xs.length-1):.5),Y=v=>H-B-(H-B-T)*(f(v)-lo)/(hi-lo),t=[];
if(log)for(let e=lo;e<=Math.floor(hi);e++)t.push(Math.pow(10,e));else{const st=Math.max(1,Math.ceil(hi/6));for(let v=0;v<=hi;v+=st)t.push(v)}
x.font="11px Arial";x.textBaseline="middle";x.textAlign="right";for(const v of t){x.strokeStyle="#22304a";x.beginPath();x.moveTo(L,Y(v));x.lineTo(W-R,Y(v));x.stroke();x.fillStyle="#93a4c0";x.fillText(v,L-6,Y(v))}
x.textAlign="center";xs.forEach((v,i)=>x.fillText(v,X(i),H-B+14));x.textAlign="left";x.fillStyle="#eaf1ff";x.font="bold 12px Arial";x.fillText(title+" (x: N courses)",L,12);
ser.forEach((s,k)=>{x.strokeStyle=x.fillStyle=s.color;x.lineWidth=2;x.beginPath();s.ys.forEach((v,i)=>i?x.lineTo(X(i),Y(v)):x.moveTo(X(i),Y(v)));x.stroke();
s.ys.forEach((v,i)=>{x.beginPath();x.arc(X(i),Y(v),3,0,7);x.fill()});x.font="11px Arial";x.fillText("o "+s.name,W-R-120,T+8+k*14)})}
if(D.bench){const B=D.bench,col={"Welsh-Powell":"#ffd166","DSatur":"#55e6ff","Exact B&B":"#5df2b0"},mk=o=>Object.keys(o).map(k=>({name:k,color:col[k],ys:o[k]}));
$("bm").textContent=`Random graphs, R = ${B.r}, density ${(B.density*100).toFixed(0)}%, exact limit ${B.limit}s per size.`;
chart("c1",B.ns,mk(B.slots),false,"Slots used");chart("c2",B.ns,mk(B.times),true,"Running time, ms (log)")}
render();
</script></body></html>"""


def write_html(g, r, results, path, bench=None):
    """Standalone offline report: all numbers come from the Python solver."""
    import json
    data = {"n": g.n, "r": r,
            "edges": [[u, v] for u in range(g.n) for v in g.adj[u] if u < v],
            "results": [{"name": x.name, "color": x.color, "order": x.order,
                         "slots": x.slots, "ms": x.ms, "nodes": x.nodes,
                         "optimal": x.optimal, "lb": x.lb, "valid": x.valid}
                        for x in results],
            "bench": bench}
    with open(path, "w", encoding="utf-8") as f:
        f.write(HTML.replace("__DATA__", json.dumps(data)))


# ------------------------------------------------------------------ main ----
def interactive(a):
    """No arguments given: ask for Option 1 or Option 2 on the console."""
    print("Option 1: enter 'N M R' then M lines 'u v' (blank line to finish)")
    print("Option 2: enter 'N R' only, then you will be asked for the density")
    lines = []
    while True:
        line = input("> ").strip()
        if not line:
            break
        lines.append(line)
    if not lines:
        raise ValueError("No input given.")
    first = lines[0].split()
    if len(first) == 2:
        n, r = int(first[0]), int(first[1])
        if r < 1:
            raise ValueError("R must be >= 1.")
        a.density = float(input("Edge density (0..1): "))
        return random_graph(n, a.density, a.seed), r
    return parse_input("\n".join(lines))


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--file", help="Option 1 input file ('-' for stdin)")
    ap.add_argument("--random", nargs=2, type=int, metavar=("N", "R"),
                    help="Option 2: random graph with N courses and R halls")
    ap.add_argument("--density", type=float, default=0.25, help="edge density 0..1")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--limit", type=float, default=3.0, help="exact solver seconds")
    ap.add_argument("--out", default="timetable.csv")
    ap.add_argument("--view", default="Exact B&B",
                    choices=["Welsh-Powell", "DSatur", "Exact B&B"])
    ap.add_argument("--html", metavar="FILE",
                    help="write a standalone HTML report (graph, grid, charts, animation)")
    ap.add_argument("--bench-max", type=int, default=30,
                    help="largest N for the chart in the HTML report")
    ap.add_argument("--plot", action="store_true")
    ap.add_argument("--animate", action="store_true")
    ap.add_argument("--bench", type=int, metavar="MAX_N",
                    help="compare algorithms for N = 6..MAX_N (needs --random N R for R)")
    a = ap.parse_args()

    try:
        if a.bench:
            if not a.random:
                ap.error("--bench needs --random N R (R is used; N is ignored)")
            benchmark(a.random[1], a.density, a.bench, min(a.limit, 1.0))
            return
        if a.file:
            text = sys.stdin.read() if a.file == "-" else open(a.file).read()
            g, r = parse_input(text)
        elif a.random:
            n, r = a.random
            if r < 1:
                raise ValueError("R must be >= 1.")
            g = random_graph(n, a.density, a.seed)
        else:
            g, r = interactive(a)
    except (ValueError, OSError) as e:
        sys.exit(f"Input error: {e}")

    results = run_all(g, r, a.limit)
    print_report(g, r, results)
    chosen = next(x for x in results if x.name == a.view)
    print_timetable(g, chosen)
    write_csv(g, chosen, a.out)
    print(f"\nCSV written to {a.out}")
    if a.html:
        bench = bench_data(r, a.density, a.bench_max, min(a.limit, 1.0))
        write_html(g, r, results, a.html, bench)
        print(f"HTML report written to {a.html}")
    if a.plot:
        plot_result(g, chosen)
    if a.animate:
        animate_result(g, chosen)


if __name__ == "__main__":
    main()
